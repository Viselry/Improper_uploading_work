import java.io.*;

public class Utils {

    // Reads the content of a text file.
    public static String readContentFromFile(String path) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return content.toString();
    }

    // Writes content to a file, overwriting any existing content.
    public static void writeContentToFile(String path, String content) {
        try (PrintWriter writer = new PrintWriter(new FileWriter(path))) {
            writer.print(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Appends content to the end of a file.
    public static void appendContentToFile(String path, String content) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(path, true))) {
            writer.append(content);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Searches for a file within a directory.
    public static File findFileByName(String folderPath, String fileName) {
        File folder = new File(folderPath);
        File[] files = folder.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().equals(fileName)) {
                    return file;
                }
            }
        }
        return null;
    }

    public static void main(String[] args) {
        // Read content from a text file.
        String filePath = "C:\Users\ADMIN\Desktop\OOP\IO utility\\Ex1.txt";
        String content = Utils.readContentFromFile(filePath);
        System.out.println("Content of the file:\n" + content);

        // Write content to a file, overwriting existing content.
        String newPath = "C:\Users\ADMIN\Desktop\OOP\IO utility\\Ex2.txt";
        Utils.writeContentToFile(newPath, "New content");

        // Append content to the end of a file.
        String existingPath = "C:\Users\ADMIN\Desktop\OOP\IO utility\\Ex3.txt";
        Utils.appendContentToFile(existingPath, "\nAppended content");

        // Search for a file within a directory.
        String folderPath = "C:\Users\ADMIN\Desktop\OOP";
        String fileNameToFind = "C:\Users\ADMIN\Desktop\OOP\IO utility\\Ex4.txt";
        File foundFile = Utils.findFileByName(folderPath, fileNameToFind);

        if (foundFile != null) {
            System.out.println("File found: " + foundFile.getAbsolutePath());
        } else {
            System.out.println("File not found.");
        }
    }
}
