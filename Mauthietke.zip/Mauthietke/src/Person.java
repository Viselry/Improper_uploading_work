interface Person {
    void displayDetails();
}
