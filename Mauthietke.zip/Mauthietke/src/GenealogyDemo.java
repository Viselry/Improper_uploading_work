public class GenealogyDemo {

    public static void main(String[] args) {
        // Create individuals
        Person maria = new Person("Maria", "Female", "01/01/1970");
        Person juan = new Person("Juan", "Male", "05/05/1975");
        Person sofia = new Person("Sofia", "Female", "10/10/1995");
        Person alejandro = new Person("Alejandro", "Male", "15/08/2000");
        Person laura = new Person("Laura", "Female", "20/12/1998");

        // Create families
        Family garciaFamily = new Family("Garcia Family");
        garciaFamily.addMember(maria);
        garciaFamily.addMember(juan);

        Family moralesFamily = new Family("Morales Family");
        moralesFamily.addMember(sofia);
        moralesFamily.addMember(alejandro);

        // Build the genealogy tree
        garciaFamily.addChild(sofia);
        garciaFamily.addChild(alejandro);
        garciaFamily.marryIn(moralesFamily);

        // Add additional family (optional)
        Person david = new Person("David", "Male", "08/08/1980");
        Family lopezFamily = new Family("Lopez Family");
        lopezFamily.addMember(david);
        lopezFamily.addMember(laura);
        garciaFamily.marryIn(lopezFamily);

        // Display details
        printHeading("Unmarried Individuals:");
        printUnmarried(garciaFamily);

        printHeading("\nCouples with Two Children:");
        printCouplesWithTwoChildren(garciaFamily);

        printHeading("\nThe Latest Generation:");
        printLatestGeneration(garciaFamily);
    }

    private static void printUnmarried(Person person) {
        if (person.isIndividual() && !person.isMarried()) {
            System.out.println(person);
        } else if (person.isFamily()) {
            for (Person member : ((Family) person).getMembers()) {
                printUnmarried(member);
            }
        }
    }

    private static void printCouplesWithTwoChildren(Person person) {
        if (person.isFamily()) {
            Family family = (Family) person;
            if (family.hasTwoChildren()) {
                System.out.println(family);
            }
            for (Person member : family.getMembers()) {
                printCouplesWithTwoChildren(member);
            }
        }
    }

    private static void printLatestGeneration(Person person) {
        if (!person.hasChildren()) {
            System.out.println(person);
        } else if (person.isFamily()) {
            for (Person member : ((Family) person).getMembers()) {
                printLatestGeneration(member);
            }
        }
    }

    private static void printHeading(String heading) {
        System.out.println("\n" + heading);
    }
}
