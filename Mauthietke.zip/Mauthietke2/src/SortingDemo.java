public class SortingDemo {

    public static void main(String[] args) {
        int[] numbers = {1, 2, 3, 4, 5};

        // Utilize a single Sorter with different strategies for each sort.
        Sorter sorter = new Sorter(new BubbleSort());
        sorter.performSort(numbers.clone());
        System.out.println("Using Bubble Sort:");

        sorter.setSortingStrategy(new SelectionSort());
        sorter.performSort(numbers.clone());
        System.out.println("Using Selection Sort:");
    }
}
