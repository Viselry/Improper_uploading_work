interface SortingStrategy {
    int[] sort(int[] array);
}